import requests
import json
from requests import Response

def login(url,username,pwd,contentType):
    body={}
    body["username"]=username
    body["encryptedPasswd"]=pwd
    print(body)
    headers={}
    headers["Content-Type"]=contentType
    response= requests.post(url, data=json.dumps(body), headers=headers)
    return response

# 调用函数返回信息  密码处理需要问开发
response=login("http://10.192.19.250:8000/api/user/login","admin@bitmain.com",
               "8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92","application/json; charset=utf-8")
#将json转换为python类型
data=json.loads(response.text)
if data["message"]=="login success" and response.status_code==200:
            print("登陆成功！")
else:  #抛出异常
    raise Exception(data["message"])